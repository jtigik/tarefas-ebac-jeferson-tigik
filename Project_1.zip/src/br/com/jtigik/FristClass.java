package br.com.jtigik;

public class FristClass {

	public static void main(String[] args) {
		
		System.out.println("Hello World!!!");

	}

}
